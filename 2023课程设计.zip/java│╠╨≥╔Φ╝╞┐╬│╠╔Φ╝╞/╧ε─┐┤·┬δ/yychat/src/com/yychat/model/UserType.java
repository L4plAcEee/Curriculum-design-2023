package com.yychat.model;

public interface UserType {
	String USER_LOGIN_VALIDATE="1";
	String USER_REGISTER="2";
}
