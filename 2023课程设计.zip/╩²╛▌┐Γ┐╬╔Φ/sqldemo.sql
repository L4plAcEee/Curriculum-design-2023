/*
Navicat MySQL Data Transfer

Source Server         : mysql1
Source Server Version : 50624
Source Host           : localhost:3306
Source Database       : sqldemo

Target Server Type    : MYSQL
Target Server Version : 50624
File Encoding         : 65001

Date: 2024-06-13 21:02:01
*/

SET FOREIGN_KEY_CHECKS=0;

-- ----------------------------
-- Table structure for expenserecord
-- ----------------------------
DROP TABLE IF EXISTS `expenserecord`;
CREATE TABLE `expenserecord` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `LivestockID` int(11) DEFAULT NULL,
  `ExpenseDate` date DEFAULT NULL,
  `Amount` decimal(10,2) DEFAULT NULL,
  `Description` varchar(200) DEFAULT NULL,
  PRIMARY KEY (`ID`),
  KEY `LivestockID` (`LivestockID`),
  CONSTRAINT `expenserecord_ibfk_1` FOREIGN KEY (`LivestockID`) REFERENCES `livestock` (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of expenserecord
-- ----------------------------

-- ----------------------------
-- Table structure for livestock
-- ----------------------------
DROP TABLE IF EXISTS `livestock`;
CREATE TABLE `livestock` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `Weight` int(10) DEFAULT NULL,
  `HealthStatus` int(50) DEFAULT NULL,
  `PenID` int(11) DEFAULT NULL,
  PRIMARY KEY (`ID`),
  KEY `PenID` (`PenID`),
  CONSTRAINT `livestock_ibfk_1` FOREIGN KEY (`PenID`) REFERENCES `pen` (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of livestock
-- ----------------------------

-- ----------------------------
-- Table structure for manager
-- ----------------------------
DROP TABLE IF EXISTS `manager`;
CREATE TABLE `manager` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `Name` varchar(100) DEFAULT NULL,
  `ContactNumber` varchar(20) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of manager
-- ----------------------------

-- ----------------------------
-- Table structure for pen
-- ----------------------------
DROP TABLE IF EXISTS `pen`;
CREATE TABLE `pen` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `PenNumber` varchar(50) NOT NULL,
  `Location` varchar(100) DEFAULT NULL,
  `Capacity` int(11) DEFAULT NULL,
  `CurrentOccupancy` int(11) DEFAULT NULL,
  `ManagerID` int(11) DEFAULT NULL,
  PRIMARY KEY (`ID`),
  KEY `ManagerID` (`ManagerID`),
  CONSTRAINT `pen_ibfk_1` FOREIGN KEY (`ManagerID`) REFERENCES `manager` (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of pen
-- ----------------------------

-- ----------------------------
-- Table structure for salerecord
-- ----------------------------
DROP TABLE IF EXISTS `salerecord`;
CREATE TABLE `salerecord` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `LivestockID` int(11) DEFAULT NULL,
  `SaleDate` date DEFAULT NULL,
  `SalePrice` decimal(10,2) DEFAULT NULL,
  `BuyerContact` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`ID`),
  KEY `LivestockID` (`LivestockID`),
  CONSTRAINT `salerecord_ibfk_1` FOREIGN KEY (`LivestockID`) REFERENCES `livestock` (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of salerecord
-- ----------------------------

-- ----------------------------
-- View structure for pentotalrevenue
-- ----------------------------
DROP VIEW IF EXISTS `pentotalrevenue`;
CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost`  VIEW `pentotalrevenue` AS SELECT 
    Livestock.PenID,
    SUM(SaleRecord.SalePrice) AS TotalRevenue
FROM 
    SaleRecord
JOIN 
    Livestock ON SaleRecord.LivestockID = Livestock.ID
GROUP BY 
    Livestock.PenID ;

-- ----------------------------
-- View structure for view_penstatus
-- ----------------------------
DROP VIEW IF EXISTS `view_penstatus`;
CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost`  VIEW `view_penstatus` AS SELECT 
    Pen.ID AS PenID,
    Pen.Capacity,
    Pen.CurrentOccupancy,
    (Pen.Capacity - Pen.CurrentOccupancy) AS AvailableSpace
FROM 
    Pen ;

-- ----------------------------
-- Procedure structure for InsertLivestock
-- ----------------------------
DROP PROCEDURE IF EXISTS `InsertLivestock`;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `InsertLivestock`(
    IN p_Breed VARCHAR(50),
    IN p_BirthDate DATE,
    IN p_Weight DECIMAL(10, 2),
    IN p_HealthStatus VARCHAR(50),
    IN p_PenID INT
)
BEGIN
    DECLARE currentOccupancy INT;
    DECLARE penCapacity INT;

    -- 获取当前兽栏的占用量和容量
    SELECT CurrentOccupancy, Capacity INTO currentOccupancy, penCapacity 
    FROM Pen 
    WHERE ID = p_PenID FOR UPDATE;

    -- 检查插入新牲畜后是否会超过容量
    IF currentOccupancy + 1 > penCapacity THEN
        SIGNAL SQLSTATE '45000'
        SET MESSAGE_TEXT = 'Pen capacity exceeded';
    ELSE
        -- 插入新的牲畜记录
        INSERT INTO Livestock (Breed, BirthDate, Weight, HealthStatus, PenID)
        VALUES (p_Breed, p_BirthDate, p_Weight, p_HealthStatus, p_PenID);

        -- 更新兽栏的当前占用量
        UPDATE Pen 
        SET CurrentOccupancy = CurrentOccupancy + 1 
        WHERE ID = p_PenID;
    END IF;
END
;;
DELIMITER ;
DROP TRIGGER IF EXISTS `CheckPenCapacityBeforeInsert`;
DELIMITER ;;
CREATE TRIGGER `CheckPenCapacityBeforeInsert` BEFORE INSERT ON `livestock` FOR EACH ROW BEGIN
    DECLARE occupancy INT;
    SELECT CurrentOccupancy INTO occupancy FROM Pen WHERE ID = NEW.PenID;
    IF occupancy >= (SELECT Capacity FROM Pen WHERE ID = NEW.PenID) THEN
        SIGNAL SQLSTATE '45000'
        SET MESSAGE_TEXT = 'Pen capacity exceeded';
    END IF;
END
;;
DELIMITER ;
DROP TRIGGER IF EXISTS `UpdatePenOccupancyAfterInsert`;
DELIMITER ;;
CREATE TRIGGER `UpdatePenOccupancyAfterInsert` AFTER INSERT ON `livestock` FOR EACH ROW BEGIN
    UPDATE Pen SET CurrentOccupancy = CurrentOccupancy + 1 WHERE ID = NEW.PenID;
END
;;
DELIMITER ;
DROP TRIGGER IF EXISTS `UpdatePenOccupancyAfterDelete`;
DELIMITER ;;
CREATE TRIGGER `UpdatePenOccupancyAfterDelete` AFTER DELETE ON `livestock` FOR EACH ROW BEGIN
    UPDATE Pen SET CurrentOccupancy = CurrentOccupancy - 1 WHERE ID = OLD.PenID;
END
;;
DELIMITER ;
