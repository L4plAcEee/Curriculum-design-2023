package model;

import java.math.BigDecimal;
import java.util.Date;

public class ExpenseRecord {
    private int id;
    private int livestockId;
    private Date expenseDate;
    private BigDecimal amount;
    private String description;

    // Constructor
    public ExpenseRecord() {
    }

    public ExpenseRecord(int id, int livestockId, Date expenseDate, BigDecimal amount, String description) {
        this.id = id;
        this.livestockId = livestockId;
        this.expenseDate = expenseDate;
        this.amount = amount;
        this.description = description;
    }

    // Getter and Setter methods
    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public int getLivestockId() {
        return livestockId;
    }

    public void setLivestockId(int livestockId) {
        this.livestockId = livestockId;
    }

    public Date getExpenseDate() {
        return expenseDate;
    }

    public void setExpenseDate(Date expenseDate) {
        this.expenseDate = expenseDate;
    }

    public BigDecimal getAmount() {
        return amount;
    }

    public void setAmount(BigDecimal amount) {
        this.amount = amount;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }
}

