package model;

public class Livestock {
    private int id;
    private int weight;
    private String healthStatus;
    private int penId;

    // Constructor
    public Livestock() {
    }

    public Livestock(int id, int weight, String healthStatus, int penId) {
        this.id = id;
        this.weight = weight;
        this.healthStatus = healthStatus;
        this.penId = penId;
    }

    // Getter and Setter methods
    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public int getWeight() {
        return weight;
    }

    public void setWeight(int weight) {
        this.weight = weight;
    }

    public String getHealthStatus() {
        return healthStatus;
    }

    public void setHealthStatus(String healthStatus) {
        this.healthStatus = healthStatus;
    }

    public int getPenId() {
        return penId;
    }

    public void setPenId(int penId) {
        this.penId = penId;
    }
}

