package view;

import javax.swing.*;

import DBL.ManagerDAO;
import model.Manager;

import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.SQLException;
import java.util.List;

public class ManagerWindow extends JFrame {

    private ManagerDAO managerDAO;
    private JTextArea displayArea;

    public ManagerWindow() {
        managerDAO = new ManagerDAO();
        setTitle("管理管理员");
        setSize(600, 400);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setLocationRelativeTo(null);

        displayArea = new JTextArea();
        displayArea.setEditable(false);
        JScrollPane scrollPane = new JScrollPane(displayArea);

        JButton addButton = new JButton("添加");
        addButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                addManager();
            }
        });

        JButton updateButton = new JButton("更新");
        updateButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                updateManager();
            }
        });

        JButton deleteButton = new JButton("删除");
        deleteButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                deleteManager();
            }
        });

        JButton viewButton = new JButton("查看所有");
        viewButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                viewAllManagers();
            }
        });

        JPanel buttonPanel = new JPanel();
        buttonPanel.add(addButton);
        buttonPanel.add(updateButton);
        buttonPanel.add(deleteButton);
        buttonPanel.add(viewButton);

        add(scrollPane, BorderLayout.CENTER);
        add(buttonPanel, BorderLayout.SOUTH);

        setVisible(true);
    }

    private void addManager() {
        JTextField nameField = new JTextField();
        JTextField contactNumberField = new JTextField();
        Object[] fields = {
            "姓名:", nameField,
            "联系电话:", contactNumberField
        };

        int option = JOptionPane.showConfirmDialog(this, fields, "添加新管理员", JOptionPane.OK_CANCEL_OPTION);
        if (option == JOptionPane.OK_OPTION) {
            Manager manager = new Manager();
            manager.setName(nameField.getText());
            manager.setContactNumber(contactNumberField.getText());

            try {
                managerDAO.addManager(manager);
                JOptionPane.showMessageDialog(this, "添加成功！");
                viewAllManagers();
            } catch (SQLException e) {
                e.printStackTrace();
                JOptionPane.showMessageDialog(this, "添加失败：" + e.getMessage(), "错误", JOptionPane.ERROR_MESSAGE);
            }
        }
    }

    private void updateManager() {
        JTextField idField = new JTextField();
        JTextField nameField = new JTextField();
        JTextField contactNumberField = new JTextField();
        Object[] fields = {
            "ID:", idField,
            "姓名:", nameField,
            "联系电话:", contactNumberField
        };

        int option = JOptionPane.showConfirmDialog(this, fields, "更新管理员信息", JOptionPane.OK_CANCEL_OPTION);
        if (option == JOptionPane.OK_OPTION) {
            Manager manager = new Manager();
            manager.setId(Integer.parseInt(idField.getText()));
            manager.setName(nameField.getText());
            manager.setContactNumber(contactNumberField.getText());

            try {
                managerDAO.updateManager(manager);
                JOptionPane.showMessageDialog(this, "更新成功！");
                viewAllManagers();
            } catch (SQLException e) {
                e.printStackTrace();
                JOptionPane.showMessageDialog(this, "更新失败：" + e.getMessage(), "错误", JOptionPane.ERROR_MESSAGE);
            }
        }
    }

    private void deleteManager() {
        String idStr = JOptionPane.showInputDialog(this, "请输入要删除的管理员ID:");
        if (idStr != null && !idStr.isEmpty()) {
            int id = Integer.parseInt(idStr);
            try {
                managerDAO.deleteManager(id);
                JOptionPane.showMessageDialog(this, "删除成功！");
                viewAllManagers();
            } catch (SQLException e) {
                e.printStackTrace();
                JOptionPane.showMessageDialog(this, "删除失败：" + e.getMessage(), "错误", JOptionPane.ERROR_MESSAGE);
            }
        }
    }

    private void viewAllManagers() {
        try {
            List<Manager> managerList = managerDAO.getAllManagers();
            displayArea.setText("");
            for (Manager manager : managerList) {
                displayArea.append("ID: " + manager.getId() + ", 姓名: " + manager.getName() +
                        ", 联系电话: " + manager.getContactNumber() + "\n");
            }
        } catch (SQLException e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(this, "无法获取数据：" + e.getMessage(), "错误", JOptionPane.ERROR_MESSAGE);
        }
    }
}

