package view;

import javax.swing.*;

import DBL.ExpenseRecordDAO;
import model.ExpenseRecord;

import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.math.BigDecimal;
import java.sql.SQLException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.List;

public class ExpenseRecordWindow extends JFrame {

    private ExpenseRecordDAO expenseRecordDAO;
    private JTextArea displayArea;
    private SimpleDateFormat dateFormat;

    public ExpenseRecordWindow() {
        expenseRecordDAO = new ExpenseRecordDAO();
        dateFormat = new SimpleDateFormat("yyyy-MM-dd");
        setTitle("管理支出记录");
        setSize(600, 400);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setLocationRelativeTo(null);

        displayArea = new JTextArea();
        displayArea.setEditable(false);
        JScrollPane scrollPane = new JScrollPane(displayArea);

        JButton addButton = new JButton("添加");
        addButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                addExpenseRecord();
            }
        });

        JButton updateButton = new JButton("更新");
        updateButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                updateExpenseRecord();
            }
        });

        JButton deleteButton = new JButton("删除");
        deleteButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                deleteExpenseRecord();
            }
        });

        JButton viewButton = new JButton("查看所有");
        viewButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                viewAllExpenseRecords();
            }
        });

        JPanel buttonPanel = new JPanel();
        buttonPanel.add(addButton);
        buttonPanel.add(updateButton);
        buttonPanel.add(deleteButton);
        buttonPanel.add(viewButton);

        add(scrollPane, BorderLayout.CENTER);
        add(buttonPanel, BorderLayout.SOUTH);

        setVisible(true);
    }

    private void addExpenseRecord() {
        JTextField livestockIdField = new JTextField();
        JTextField expenseDateField = new JTextField();
        JTextField amountField = new JTextField();
        JTextField descriptionField = new JTextField();
        Object[] fields = {
            "牲畜ID:", livestockIdField,
            "支出日期 (yyyy-MM-dd):", expenseDateField,
            "金额:", amountField,
            "描述:", descriptionField
        };

        int option = JOptionPane.showConfirmDialog(this, fields, "添加新支出记录", JOptionPane.OK_CANCEL_OPTION);
        if (option == JOptionPane.OK_OPTION) {
            ExpenseRecord record = new ExpenseRecord();
            record.setLivestockId(Integer.parseInt(livestockIdField.getText()));
            try {
                record.setExpenseDate(dateFormat.parse(expenseDateField.getText()));
            } catch (ParseException e) {
                e.printStackTrace();
                JOptionPane.showMessageDialog(this, "日期格式错误", "错误", JOptionPane.ERROR_MESSAGE);
                return;
            }
            record.setAmount(new BigDecimal(amountField.getText()));
            record.setDescription(descriptionField.getText());

            try {
                expenseRecordDAO.addExpenseRecord(record);
                JOptionPane.showMessageDialog(this, "添加成功！");
                viewAllExpenseRecords();
            } catch (SQLException e) {
                e.printStackTrace();
                JOptionPane.showMessageDialog(this, "添加失败：" + e.getMessage(), "错误", JOptionPane.ERROR_MESSAGE);
            }
        }
    }

    private void updateExpenseRecord() {
        JTextField idField = new JTextField();
        JTextField livestockIdField = new JTextField();
        JTextField expenseDateField = new JTextField();
        JTextField amountField = new JTextField();
        JTextField descriptionField = new JTextField();
        Object[] fields = {
            "ID:", idField,
            "牲畜ID:", livestockIdField,
            "支出日期 (yyyy-MM-dd):", expenseDateField,
            "金额:", amountField,
            "描述:", descriptionField
        };

        int option = JOptionPane.showConfirmDialog(this, fields, "更新支出记录", JOptionPane.OK_CANCEL_OPTION);
        if (option == JOptionPane.OK_OPTION) {
            ExpenseRecord record = new ExpenseRecord();
            record.setId(Integer.parseInt(idField.getText()));
            record.setLivestockId(Integer.parseInt(livestockIdField.getText()));
            try {
                record.setExpenseDate(dateFormat.parse(expenseDateField.getText()));
            } catch (ParseException e) {
                e.printStackTrace();
                JOptionPane.showMessageDialog(this, "日期格式错误", "错误", JOptionPane.ERROR_MESSAGE);
                return;
            }
            record.setAmount(new BigDecimal(amountField.getText()));
            record.setDescription(descriptionField.getText());

            try {
                expenseRecordDAO.updateExpenseRecord(record);
                JOptionPane.showMessageDialog(this, "更新成功！");
                viewAllExpenseRecords();
            } catch (SQLException e) {
                e.printStackTrace();
                JOptionPane.showMessageDialog(this, "更新失败：" + e.getMessage(), "错误", JOptionPane.ERROR_MESSAGE);
            }
        }
    }

    private void deleteExpenseRecord() {
        String idStr = JOptionPane.showInputDialog(this, "请输入要删除的支出记录ID:");
        if (idStr != null && !idStr.isEmpty()) {
            int id = Integer.parseInt(idStr);
            try {
                expenseRecordDAO.deleteExpenseRecord(id);
                JOptionPane.showMessageDialog(this, "删除成功！");
                viewAllExpenseRecords();
            } catch (SQLException e) {
                e.printStackTrace();
                JOptionPane.showMessageDialog(this, "删除失败：" + e.getMessage(), "错误", JOptionPane.ERROR_MESSAGE);
            }
        }
    }

    private void viewAllExpenseRecords() {
        try {
            List<ExpenseRecord> recordList = expenseRecordDAO.getAllExpenseRecords();
            displayArea.setText("");
            for (ExpenseRecord record : recordList) {
                displayArea.append("ID: " + record.getId() + ", 牲畜ID: " + record.getLivestockId() +
                        ", 支出日期: " + dateFormat.format(record.getExpenseDate()) + ", 金额: " + record.getAmount() +
                        ", 描述: " + record.getDescription() + "\n");
            }
        } catch (SQLException e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(this, "无法获取数据：" + e.getMessage(), "错误", JOptionPane.ERROR_MESSAGE);
        }
    }
}

