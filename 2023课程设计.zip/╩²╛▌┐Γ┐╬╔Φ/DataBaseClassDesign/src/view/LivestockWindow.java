package view;

import javax.swing.*;

import DBL.LivestockDAO;
import model.Livestock;

import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.SQLException;
import java.util.List;

public class LivestockWindow extends JFrame {

    private LivestockDAO livestockDAO;
    private JTextArea displayArea;

    public LivestockWindow() {
        livestockDAO = new LivestockDAO();
        setTitle("管理牲畜记录");
        setSize(600, 400);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setLocationRelativeTo(null);

        displayArea = new JTextArea();
        displayArea.setEditable(false);
        JScrollPane scrollPane = new JScrollPane(displayArea);

        JButton addButton = new JButton("添加");
        addButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                addLivestock();
            }
        });

        JButton updateButton = new JButton("更新");
        updateButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                updateLivestock();
            }
        });

        JButton deleteButton = new JButton("删除");
        deleteButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                deleteLivestock();
            }
        });

        JButton viewButton = new JButton("查看所有");
        viewButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                viewAllLivestock();
            }
        });

        JPanel buttonPanel = new JPanel();
        buttonPanel.add(addButton);
        buttonPanel.add(updateButton);
        buttonPanel.add(deleteButton);
        buttonPanel.add(viewButton);

        add(scrollPane, BorderLayout.CENTER);
        add(buttonPanel, BorderLayout.SOUTH);

        setVisible(true);
    }

    private void addLivestock() {
        JTextField weightField = new JTextField();
        JTextField healthStatusField = new JTextField();
        JTextField penIdField = new JTextField();
        Object[] fields = {
            "重量:", weightField,
            "健康状况:", healthStatusField,
            "圈栏ID:", penIdField
        };

        int option = JOptionPane.showConfirmDialog(this, fields, "添加新牲畜", JOptionPane.OK_CANCEL_OPTION);
        if (option == JOptionPane.OK_OPTION) {
            Livestock livestock = new Livestock();
            livestock.setWeight(Integer.parseInt(weightField.getText()));
            livestock.setHealthStatus(healthStatusField.getText());
            livestock.setPenId(Integer.parseInt(penIdField.getText()));

            try {
                livestockDAO.addLivestock(livestock);
                JOptionPane.showMessageDialog(this, "添加成功！");
                viewAllLivestock();
            } catch (SQLException e) {
                e.printStackTrace();
                JOptionPane.showMessageDialog(this, "添加失败：" + e.getMessage(), "错误", JOptionPane.ERROR_MESSAGE);
            }
        }
    }

    private void updateLivestock() {
        JTextField idField = new JTextField();
        JTextField weightField = new JTextField();
        JTextField healthStatusField = new JTextField();
        JTextField penIdField = new JTextField();
        Object[] fields = {
            "ID:", idField,
            "重量:", weightField,
            "健康状况:", healthStatusField,
            "圈栏ID:", penIdField
        };

        int option = JOptionPane.showConfirmDialog(this, fields, "更新牲畜记录", JOptionPane.OK_CANCEL_OPTION);
        if (option == JOptionPane.OK_OPTION) {
            Livestock livestock = new Livestock();
            livestock.setId(Integer.parseInt(idField.getText()));
            livestock.setWeight(Integer.parseInt(weightField.getText()));
            livestock.setHealthStatus(healthStatusField.getText());
            livestock.setPenId(Integer.parseInt(penIdField.getText()));

            try {
                livestockDAO.updateLivestock(livestock);
                JOptionPane.showMessageDialog(this, "更新成功！");
                viewAllLivestock();
            } catch (SQLException e) {
                e.printStackTrace();
                JOptionPane.showMessageDialog(this, "更新失败：" + e.getMessage(), "错误", JOptionPane.ERROR_MESSAGE);
            }
        }
    }

    private void deleteLivestock() {
        String idStr = JOptionPane.showInputDialog(this, "请输入要删除的牲畜ID:");
        if (idStr != null && !idStr.isEmpty()) {
            int id = Integer.parseInt(idStr);
            try {
                livestockDAO.deleteLivestock(id);
                JOptionPane.showMessageDialog(this, "删除成功！");
                viewAllLivestock();
            } catch (SQLException e) {
                e.printStackTrace();
                JOptionPane.showMessageDialog(this, "删除失败：" + e.getMessage(), "错误", JOptionPane.ERROR_MESSAGE);
            }
        }
    }

    private void viewAllLivestock() {
        try {
            List<Livestock> livestockList = livestockDAO.getAllLivestock();
            displayArea.setText("");
            for (Livestock livestock : livestockList) {
                displayArea.append("ID: " + livestock.getId() + ", 重量: " + livestock.getWeight() +
                        ", 健康状况: " + livestock.getHealthStatus() + ", 圈栏ID: " + livestock.getPenId() + "\n");
            }
        } catch (SQLException e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(this, "无法获取数据：" + e.getMessage(), "错误", JOptionPane.ERROR_MESSAGE);
        }
    }
}

