package view;


import javax.swing.*;
import javax.swing.table.DefaultTableModel;

import DBL.DatabaseConnection;

import java.awt.*;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class MultiTableQueryWindow extends JFrame {
    private JTable table;
    private DefaultTableModel tableModel;

    public MultiTableQueryWindow() {
        setTitle("多表查询结果");
        setSize(800, 600);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setLocationRelativeTo(null);

        tableModel = new DefaultTableModel();
        table = new JTable(tableModel);

        JScrollPane scrollPane = new JScrollPane(table);
        add(scrollPane, BorderLayout.CENTER);

        fetchData();
        setVisible(true);
    }

    private void fetchData() {
        try (Connection connection = DatabaseConnection.getConnection()) {
            String query = "SELECT e.ID AS ExpenseID, e.ExpenseDate, e.Amount, e.Description, " +
                           "l.ID AS LivestockID, l.Weight, l.HealthStatus " +
                           "FROM expenserecord e " +
                           "JOIN livestock l ON e.LivestockID = l.ID";

            PreparedStatement statement = connection.prepareStatement(query);
            ResultSet resultSet = statement.executeQuery();

            // 获取列名
            String[] columnNames = {"支出ID", "支出日期", "金额", "描述", "牲畜ID", "牲畜重量", "健康状态"};
            for (String columnName : columnNames) {
                tableModel.addColumn(columnName);
            }

            // 获取数据
            while (resultSet.next()) {
                Object[] row = new Object[columnNames.length];
                row[0] = resultSet.getInt("ExpenseID");
                row[1] = resultSet.getDate("ExpenseDate");
                row[2] = resultSet.getBigDecimal("Amount");
                row[3] = resultSet.getString("Description");
                row[4] = resultSet.getInt("LivestockID");
                row[5] = resultSet.getInt("Weight");
                row[6] = resultSet.getInt("HealthStatus");
                tableModel.addRow(row);
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}
