package DBL;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

import model.Livestock;

public class LivestockDAO {
    public void addLivestock(Livestock livestock) throws SQLException {
        String checkPenQuery = "SELECT * FROM pen WHERE ID = ?";
        try (Connection con = DatabaseConnection.getConnection();
             PreparedStatement checkPenStmt = con.prepareStatement(checkPenQuery)) {
            checkPenStmt.setInt(1, livestock.getPenId());
            try (ResultSet rs = checkPenStmt.executeQuery()) {
                if (!rs.next()) {
                    throw new SQLException("Invalid PenID: " + livestock.getPenId());
                }
            }
        }

        String query = "INSERT INTO livestock (Weight, HealthStatus, PenID) VALUES (?, ?, ?)";
        try (Connection con = DatabaseConnection.getConnection();
             PreparedStatement ps = con.prepareStatement(query)) {
            ps.setInt(1, livestock.getWeight());
            ps.setString(2, livestock.getHealthStatus());
            ps.setInt(3, livestock.getPenId());
            ps.executeUpdate();
        }
    }

    public void updateLivestock(Livestock livestock) throws SQLException {
        String checkPenQuery = "SELECT * FROM pen WHERE ID = ?";
        try (Connection con = DatabaseConnection.getConnection();
             PreparedStatement checkPenStmt = con.prepareStatement(checkPenQuery)) {
            checkPenStmt.setInt(1, livestock.getPenId());
            try (ResultSet rs = checkPenStmt.executeQuery()) {
                if (!rs.next()) {
                    throw new SQLException("Invalid PenID: " + livestock.getPenId());
                }
            }
        }

        String query = "UPDATE livestock SET Weight = ?, HealthStatus = ?, PenID = ? WHERE ID = ?";
        try (Connection con = DatabaseConnection.getConnection();
             PreparedStatement ps = con.prepareStatement(query)) {
            ps.setInt(1, livestock.getWeight());
            ps.setString(2, livestock.getHealthStatus());
            ps.setInt(3, livestock.getPenId());
            ps.setInt(4, livestock.getId());
            ps.executeUpdate();
        }
    }

    public void deleteLivestock(int id) throws SQLException {
        String query = "DELETE FROM livestock WHERE ID = ?";
        try (Connection con = DatabaseConnection.getConnection();
             PreparedStatement ps = con.prepareStatement(query)) {
            ps.setInt(1, id);
            ps.executeUpdate();
        }
    }

    public Livestock getLivestockById(int id) throws SQLException {
        String query = "SELECT * FROM livestock WHERE ID = ?";
        try (Connection con = DatabaseConnection.getConnection();
             PreparedStatement ps = con.prepareStatement(query)) {
            ps.setInt(1, id);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    Livestock livestock = new Livestock();
                    livestock.setId(rs.getInt("ID"));
                    livestock.setWeight(rs.getInt("Weight"));
                    livestock.setHealthStatus(rs.getString("HealthStatus"));
                    livestock.setPenId(rs.getInt("PenID"));
                    return livestock;
                }
            }
        }
        return null;
    }

    public List<Livestock> getAllLivestock() throws SQLException {
        List<Livestock> livestockList = new ArrayList<>();
        String query = "SELECT * FROM livestock";
        try (Connection con = DatabaseConnection.getConnection();
             PreparedStatement ps = con.prepareStatement(query);
             ResultSet rs = ps.executeQuery()) {
            while (rs.next()) {
                Livestock livestock = new Livestock();
                livestock.setId(rs.getInt("ID"));
                livestock.setWeight(rs.getInt("Weight"));
                livestock.setHealthStatus(rs.getString("HealthStatus"));
                livestock.setPenId(rs.getInt("PenID"));
                livestockList.add(livestock);
            }
        }
        return livestockList;
    }
}


