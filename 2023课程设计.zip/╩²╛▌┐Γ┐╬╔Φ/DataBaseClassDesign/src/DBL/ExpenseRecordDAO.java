package DBL;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

import model.ExpenseRecord;

public class ExpenseRecordDAO {
    public void addExpenseRecord(ExpenseRecord record) throws SQLException {
        String query = "INSERT INTO expenserecord (LivestockID, ExpenseDate, Amount, Description) VALUES (?, ?, ?, ?)";
        try (Connection con = DatabaseConnection.getConnection();
             PreparedStatement ps = con.prepareStatement(query)) {
            ps.setInt(1, record.getLivestockId());
            ps.setDate(2, new java.sql.Date(record.getExpenseDate().getTime()));
            ps.setBigDecimal(3, record.getAmount());
            ps.setString(4, record.getDescription());
            ps.executeUpdate();
        }
    }

    public void updateExpenseRecord(ExpenseRecord record) throws SQLException {
        String query = "UPDATE expenserecord SET LivestockID = ?, ExpenseDate = ?, Amount = ?, Description = ? WHERE ID = ?";
        try (Connection con = DatabaseConnection.getConnection();
             PreparedStatement ps = con.prepareStatement(query)) {
            ps.setInt(1, record.getLivestockId());
            ps.setDate(2, new java.sql.Date(record.getExpenseDate().getTime()));
            ps.setBigDecimal(3, record.getAmount());
            ps.setString(4, record.getDescription());
            ps.setInt(5, record.getId());
            ps.executeUpdate();
        }
    }

    public void deleteExpenseRecord(int id) throws SQLException {
        String query = "DELETE FROM expenserecord WHERE ID = ?";
        try (Connection con = DatabaseConnection.getConnection();
             PreparedStatement ps = con.prepareStatement(query)) {
            ps.setInt(1, id);
            ps.executeUpdate();
        }
    }

    public ExpenseRecord getExpenseRecordById(int id) throws SQLException {
        String query = "SELECT * FROM expenserecord WHERE ID = ?";
        try (Connection con = DatabaseConnection.getConnection();
             PreparedStatement ps = con.prepareStatement(query)) {
            ps.setInt(1, id);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    ExpenseRecord record = new ExpenseRecord();
                    record.setId(rs.getInt("ID"));
                    record.setLivestockId(rs.getInt("LivestockID"));
                    record.setExpenseDate(rs.getDate("ExpenseDate"));
                    record.setAmount(rs.getBigDecimal("Amount"));
                    record.setDescription(rs.getString("Description"));
                    return record;
                }
            }
        }
        return null;
    }

    public List<ExpenseRecord> getAllExpenseRecords() throws SQLException {
        String query = "SELECT * FROM expenserecord";
        List<ExpenseRecord> recordList = new ArrayList<>();
        try (Connection con = DatabaseConnection.getConnection();
             PreparedStatement ps = con.prepareStatement(query);
             ResultSet rs = ps.executeQuery()) {
            while (rs.next()) {
                ExpenseRecord record = new ExpenseRecord();
                record.setId(rs.getInt("ID"));
                record.setLivestockId(rs.getInt("LivestockID"));
                record.setExpenseDate(rs.getDate("ExpenseDate"));
                record.setAmount(rs.getBigDecimal("Amount"));
                record.setDescription(rs.getString("Description"));
                recordList.add(record);
            }
        }
        return recordList;
    }
}

