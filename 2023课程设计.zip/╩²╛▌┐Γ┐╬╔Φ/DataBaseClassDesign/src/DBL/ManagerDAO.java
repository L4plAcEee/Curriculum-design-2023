package DBL;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

import model.Manager;

public class ManagerDAO {

    // 添加管理员
    public void addManager(Manager manager) throws SQLException {
        String query = "INSERT INTO manager (Name, ContactNumber) VALUES (?, ?)";
        try (Connection con = DatabaseConnection.getConnection();
             PreparedStatement ps = con.prepareStatement(query)) {
            ps.setString(1, manager.getName());
            ps.setString(2, manager.getContactNumber());
            ps.executeUpdate();
        }
    }

    // 更新管理员信息
    public void updateManager(Manager manager) throws SQLException {
        String query = "UPDATE manager SET Name = ?, ContactNumber = ? WHERE ID = ?";
        try (Connection con = DatabaseConnection.getConnection();
             PreparedStatement ps = con.prepareStatement(query)) {
            ps.setString(1, manager.getName());
            ps.setString(2, manager.getContactNumber());
            ps.setInt(3, manager.getId());
            ps.executeUpdate();
        }
    }

    // 删除管理员
    public void deleteManager(int id) throws SQLException {
        String query = "DELETE FROM manager WHERE ID = ?";
        try (Connection con = DatabaseConnection.getConnection();
             PreparedStatement ps = con.prepareStatement(query)) {
            ps.setInt(1, id);
            ps.executeUpdate();
        }
    }

    // 根据ID获取管理员
    public Manager getManagerById(int id) throws SQLException {
        String query = "SELECT * FROM manager WHERE ID = ?";
        try (Connection con = DatabaseConnection.getConnection();
             PreparedStatement ps = con.prepareStatement(query)) {
            ps.setInt(1, id);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    Manager manager = new Manager();
                    manager.setId(rs.getInt("ID"));
                    manager.setName(rs.getString("Name"));
                    manager.setContactNumber(rs.getString("ContactNumber"));
                    return manager;
                }
            }
        }
        return null;
    }

    // 获取所有管理员
    public List<Manager> getAllManagers() throws SQLException {
        List<Manager> managerList = new ArrayList<>();
        String query = "SELECT * FROM manager";
        try (Connection con = DatabaseConnection.getConnection();
             PreparedStatement ps = con.prepareStatement(query);
             ResultSet rs = ps.executeQuery()) {
            while (rs.next()) {
                Manager manager = new Manager();
                manager.setId(rs.getInt("ID"));
                manager.setName(rs.getString("Name"));
                manager.setContactNumber(rs.getString("ContactNumber"));
                managerList.add(manager);
            }
        }
        return managerList;
    }
}


